

<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>Name</td>
          <td>text Position</td>
            <td>Background Image</td>
            <td>Category</td>
            <td>Description</td>
            <td>Button Text</td>
            <td>Button Link</td>
          <td colspan="2">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($slider->name); ?></td>
            <td><?php echo e($slider->text_position); ?></td>
            <td><?php echo e($slider->bg_Image); ?></td>
            <td><?php echo e($slider->category); ?></td>
            <td><?php echo e($slider->description); ?></td>
            <td><?php echo e($slider->button_text); ?></td>
            <td><?php echo e($slider->button_link); ?></td>
            
            <td>
                <a href="<?php echo e(route('sliders.show',$slider->id)); ?>" class="btn btn-primary">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($sliders->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/slider/sliders.blade.php ENDPATH**/ ?>