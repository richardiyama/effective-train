<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                        <a href="<?php echo e(url('/breadcrumps')); ?>">Breadcrump</a>
                        <a href="<?php echo e(url('/columnsthrees')); ?>">Column three</a>
                        <a href="<?php echo e(url('/columnstwos')); ?>">Column two</a>
                        <a href="<?php echo e(url('/contacttopareas')); ?>">Contact Top Area</a>
                        <a href="<?php echo e(url('/contactuss')); ?>">Contact Us</a>
                        <a href="<?php echo e(url('/counterareas')); ?>">Counter Area</a>
                        <a href="<?php echo e(url('/counterups')); ?>">Counter Up</a>
                        <a href="<?php echo e(url('/findinguss')); ?>">Finding Us</a>
                        <a href="<?php echo e(url('/footers')); ?>">Footer</a>
                        <a href="<?php echo e(url('/innerabouts')); ?>">Inner About</a>
                        <a href="<?php echo e(url('/headers')); ?>">Header</a>
                        <a href="<?php echo e(url('/homess')); ?>">Home Page</a>
                        <a href="<?php echo e(url('/mapareas')); ?>">Map Area</a>
                        <a href="<?php echo e(url('/nameitems')); ?>">Name Item</a>
                        <a href="<?php echo e(url('/nameitemtwos')); ?>">Name Item Two</a>
                        <a href="<?php echo e(url('/originalservices')); ?>">Original Services</a>
                        <a href="<?php echo e(url('/posts')); ?>">Posts</a>
                        <a href="<?php echo e(url('/serviceareas')); ?>">Service Areas</a>
                        <a href="<?php echo e(url('/servicedetailss')); ?>">Service Details</a>
                        <a href="<?php echo e(url('/coursefiles')); ?>">Course File</a>

                        
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    Global Outsourcing Services Limited API
                </div>

                <div class="links">
                <a href="<?php echo e(url('/abouts')); ?>">About</a>
                        <a href="<?php echo e(url('/aboutcounterareas')); ?>">About Counter Areas</a>
                        <a href="<?php echo e(url('/aboutones')); ?>">About One</a>
                        <a href="<?php echo e(url('/abouttwos')); ?>">About Two</a>
                        <a href="<?php echo e(url('/accordions')); ?>">Accordion </a>
                        <a href="<?php echo e(url('/abouts')); ?>">About</a>
                        <a href="<?php echo e(url('/blogareas')); ?>">Blog Area </a>
                        <a href="<?php echo e(url('/brands')); ?>">Brand</a>
                        <a href="<?php echo e(url('/breadcrumbareas')); ?>">Breadcrumb Area</a>
                        <a href="<?php echo e(url('/servicedones')); ?>">Service Done</a>
                        <a href="<?php echo e(url('/singleservices')); ?>">Single Service</a>
                        <a href="<?php echo e(url('/sliders')); ?>">Silder</a>
                        <a href="<?php echo e(url('/socilas')); ?>">Social Media</a>
                        <a href="<?php echo e(url('/standardservices')); ?>">Standard Services</a>
                        <a href="<?php echo e(url('/teams')); ?>">Team</a>
                        <a href="<?php echo e(url('/teamareas')); ?>">Team Area</a>
                        <a href="<?php echo e(url('/widgets')); ?>">Widget</a>
                        <a href="<?php echo e(url('/widgetthrees')); ?>">Widget Three</a>
                        <a href="<?php echo e(url('/widgettwos')); ?>">Widget Two</a>
                       
                       
                       
                        
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\Project\gosApi\gosapi\resources\views/welcome.blade.php ENDPATH**/ ?>