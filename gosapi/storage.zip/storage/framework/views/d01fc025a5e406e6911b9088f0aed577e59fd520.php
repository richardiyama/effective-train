

<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>Name</td>
          <td>Title</td>
         <!-- <td>Inner About Title</td>
          <td>Inner About Description</td>
          <td>Two Columns Content one</td>
          <td>Two Columns Content two</td>
          <td>Three Columns Title One </td>
          <td>Three Columns Content One </td>
          <td>Three Columns Title Two </td>
          <td>Three Columns Content Two </td>
          <td>Three Columns Title Three</td>
          <td>Three Columns Content Three </td>
          <td>Finding Us Title</td>
          <td>Finding Us Content</td>
          <td>Finding Us Service Booking Url </td>
          <td>Breadcrump Title</td>
          <td>About Counter Area Content </td>
          <td>About One Image </td>
          <td>About One Title</td>
          <td>About One Content </td>-->
          <td colspan="2">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($about->name); ?></td>
            <td><?php echo e($about->title); ?></td>
         <!--   <td><?php echo e($about->innerabout->title); ?></td>
            <td><?php echo e($about->innerabout->description); ?></td>
            <td><?php echo e($about->columntwo->content_one); ?></td>
            <td><?php echo e($about->columntwo->content_two); ?></td>
            <td><?php echo e($about->columnthree->title_one); ?></td>
            <td><?php echo e($about->columnthree->content_one); ?></td>
            <td><?php echo e($about->columnthree->title_two); ?></td>
            <td><?php echo e($about->columnthree->content_two); ?></td>
            <td><?php echo e($about->columnthree->title_three); ?></td>
            <td><?php echo e($about->columnthree->content_three); ?></td>
            <td><?php echo e($about->findingus->title); ?></td>
            <td><?php echo e($about->findingus->content); ?></td>
            <td><?php echo e($about->findingus->service_booking_url); ?></td>
            <td><?php echo e($about->breadcrump->title); ?></td>
            <td><?php echo e($about->aboutcounterarea->content); ?></td>
            <td><?php echo e($about->aboutone->about_image); ?></td>
            <td><?php echo e($about->aboutone->title); ?></td>
            <td><?php echo e($about->aboutone->content); ?></td>-->
            <td>
                <a href="<?php echo e(route('abouts.show',$about->id)); ?>" class="btn btn-primary">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($abouts->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/about/abouts.blade.php ENDPATH**/ ?>