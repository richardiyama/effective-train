

<?php $__env->startSection('content'); ?>

   

<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>Name</td>
          <td>Title</td>
            <td> Description</td>
            <td> Services Urls</td>
            <td> Service Image</td>
            
          <td colspan="2">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $standardservices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $standardservice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($standardservice->name); ?></td>
            <td><?php echo e($standardservice->title); ?></td>
            <td><?php echo e($standardservice->description); ?></td>
            <td><?php echo e($standardservice->services_urls); ?></td>
            <td><?php echo e($standardservice->services_image); ?></td>
            <td>
            <form action="<?php echo e(route('standardservices.destroy',$standardservice->id)); ?>" method="POST">
   
   <a class="btn btn-info" href="<?php echo e(route('standardservices.show',$standardservice->id)); ?>">Edit</a>

   

   <?php echo csrf_field(); ?>
   

   <button type="submit" class="btn btn-danger">Delete</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($standardservices->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/standardservice/standardservices.blade.php ENDPATH**/ ?>