

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-8 offset-sm-2">
        <h1 class="display-3">Create Standard Service</h1>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <br /> 
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('standardservices.store')); ?>" enctype="multipart/form-data">
        
            <?php echo csrf_field(); ?>
            <div class="form-group">

                <label for="name">Page Name:</label>
                <input type="text" class="form-control" name="name"/>
            </div>
           
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" name="title"/>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea class="field" name="description" cols="50" rows="10"></textarea>
            </div>
            <div class="form-group">
                <label for="services_urls">Services Urls:</label>
                <textarea class="field" name="services_urls" cols="50" rows="10"></textarea>
            </div>
            
            <div class="form-group">
        <label for="images">Service Image</label>
        <div class="custom-file">
        <input type="file" class="custom-file-input" id="images" name="services_image">
            <label class="custom-file-label" for="images">Image</label>
        </div>
    </div>
           
    <div class="form-group row mt-4">

<label for="home_content" class="col-md-2 col-form-label">Home Content</label>
<div class="col-md-10">

<select class="form-control" name="home_content" id="home_content" required>
<option selected>Select Home Content</option>
<?php $__currentLoopData = $homess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($homes->id); ?>"><?php echo e($homes->title); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>

<div class="form-group row mt-4">

<label for="service_done_content" class="col-md-2 col-form-label">Service Done Content</label>
<div class="col-md-10">

<select class="form-control" name="service_done_content" id="service_done_content" required>
<option selected>Select Service Done:</option>
<?php $__currentLoopData = $servicedones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicedone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($servicedone->id); ?>"><?php echo e($servicedone->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/standardservice/create.blade.php ENDPATH**/ ?>