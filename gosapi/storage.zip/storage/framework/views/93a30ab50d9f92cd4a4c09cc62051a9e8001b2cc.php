

<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>Name</td>
          <td>Social Tag</td>
            <td>Social Url</td>
          <td colspan="2">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $socilas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($socila->name); ?></td>
            <td><?php echo e($socila->social_tag); ?></td>
            <td><?php echo e($socila->social_url); ?></td>
           
            
            <td>
                <a href="<?php echo e(route('socilas.show',$socila->id)); ?>" class="btn btn-primary">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($socilas->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/socila/socilas.blade.php ENDPATH**/ ?>