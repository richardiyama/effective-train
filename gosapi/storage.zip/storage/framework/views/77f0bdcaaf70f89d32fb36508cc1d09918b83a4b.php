

<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Blog Post</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('posts.create')); ?>"> Create New Blog Post</a>
            </div>
        </div>
    </div>
   

<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>Name</td>
          <td>Title</td>
        <td>Post Image</td>
        <td>Content One</td>
        <td>Blog Image</td>
        <td>Content Two</td>
        <td>Content Three</td>
        <td>Title Two</td>
        <td>Content Four</td>
        <td>Blog Image Two</td>
        <td>Title Three</td>
        <td>Content Five</td>
        <td>Title Four</td>
        <td>Title Five</td>
        <td>List One</td>
        <td>List Two</td>
        <td>List Three</td>
        <td>List Four</td>
        <td>List Five</td>
       <td>List Six</td>
        <td>List Seven</td>
       <td>List Eight</td>
        <td>List Nine</td>
       <td> Content Six</td>
        <td>Blog video Url</td>
       <td>Blog Image Three</td>
       <td>Content Seven</td>

          <td colspan="2">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($post->name); ?></td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->post_image); ?></td>
            <td><?php echo e($post->content_one); ?></td>
            <td><?php echo e($post->blog_image); ?></td>
            <td><?php echo e($post->content_two); ?></td>
            <td><?php echo e($post->content_three); ?></td>
            <td><?php echo e($post->title_two); ?></td>
            <td><?php echo e($post->content_four); ?></td>
            <td><?php echo e($post->blog_image_two); ?></td>
            <td><?php echo e($post->title_three); ?></td>
            <td><?php echo e($post->content_five); ?></td>
            <td><?php echo e($post->title_four); ?></td>
            <td><?php echo e($post->title_five); ?></td>
            <td><?php echo e($post->list_one); ?></td>
            <td><?php echo e($post->list_two); ?></td>
            <td><?php echo e($post->list_three); ?></td>
            <td><?php echo e($post->list_four); ?></td>
            <td><?php echo e($post->list_five); ?></td>
            <td><?php echo e($post->list_six); ?></td>
            <td><?php echo e($post->list_seven); ?></td>
            <td><?php echo e($post->list_eight); ?></td>
            <td><?php echo e($post->list_nine); ?></td>
            <td><?php echo e($post->content_six); ?></td>
            <td><?php echo e($post->blog_video); ?></td>
            <td><?php echo e($post->blog_image_three); ?></td>
            <td><?php echo e($post->content_seven); ?></td>
            <td>
            <form action="<?php echo e(route('posts.destroy',$post->id)); ?>" method="POST">
   
   <a class="btn btn-info" href="<?php echo e(route('posts.show',$post->id)); ?>">Edit</a>

   

   <?php echo csrf_field(); ?>
   

   <button type="submit" class="btn btn-danger">Delete</button>
</form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($posts->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/post/posts.blade.php ENDPATH**/ ?>