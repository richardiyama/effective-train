

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-8 offset-sm-2">
        <h1 class="display-3">Update Slider</h1>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <br /> 
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('sliders.update')); ?>" enctype="multipart/form-data">
        
            <?php echo csrf_field(); ?>
            <div class="form-group">

                <label for="name">Page Name:</label>
                <input type="text" class="form-control" name="name" value=<?php echo e($slider->name); ?> />
            </div>
            <div class="form-group">
                <label for="text_position">text Position:</label>
                <textarea class="field" name="text_position" cols="50" rows="10"  ><?php echo e($slider->text_position); ?></textarea>
            </div>
           
            <div class="form-group">
                <label for="bg_Image">Background Image:</label>
                <textarea class="field" name="bg_Image" cols="50" rows="10"  ><?php echo e($slider->bg_Image); ?></textarea>
            </div>
            <div class="form-group">
                <label for="category">Category:</label>
                <input type="text" class="form-control" name="category" value=<?php echo e($slider->category); ?> />
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <input type="text" class="form-control" name="description" value=<?php echo e($slider->description); ?> />
            </div>
            <div class="form-group">
                <label for="button_text">Button Text:</label>
                <input type="text" class="form-control" name="button_text" value=<?php echo e($slider->button_text); ?> />
            </div>
            <div class="form-group">
                <label for="button_link">Button Link:</label>
                <input type="text" class="form-control" name="button_link" value=<?php echo e($slider->button_link); ?> />
            </div>

            

            <input type="hidden" name="id" value = "<?php echo e($slider->id); ?>">

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/slider/slider.blade.php ENDPATH**/ ?>