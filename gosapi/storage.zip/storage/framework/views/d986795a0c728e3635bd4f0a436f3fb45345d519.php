

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-8 offset-sm-2">
        <h1 class="display-3">Update Social Media</h1>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <br /> 
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('socilas.update')); ?>" enctype="multipart/form-data">
        
            <?php echo csrf_field(); ?>
            <div class="form-group">

                <label for="name">Page Name:</label>
                <input type="text" class="form-control" name="name" value=<?php echo e($socila->name); ?> />
            </div>
            <div class="form-group">
                <label for="social_tag">Social Tag:</label>
                <textarea class="field" name="social_tag" cols="50" rows="10"  ><?php echo e($socila->social_tag); ?></textarea>
            </div>
           
            <div class="form-group">
                <label for="social_url">Social Url:</label>
                <textarea class="field" name="social_url" cols="50" rows="10"  ><?php echo e($socila->social_url); ?></textarea>
            </div>
          

            <input type="hidden" name="id" value = "<?php echo e($socila->id); ?>">

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/socila/socila.blade.php ENDPATH**/ ?>