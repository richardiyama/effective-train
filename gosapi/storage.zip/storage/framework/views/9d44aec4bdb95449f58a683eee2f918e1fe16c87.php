

<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>Name</td>
          <td>Title One</td>
          <td>Title Two</td>
        <td>Service Image</td>
        <td>Content One</td>
        <td>Content Two</td>
        <td>Content Three</td>
        <td>Content Four</td>
        <td>Service Booking Url </td>
        <td>List One</td>
        <td>List Two</td>
        <td>List Three</td>
        <td>List Four</td>
        <td>List Five</td>
       <td>List Six</td>
        <td>List Seven</td>
       <td>List Eight</td>
       <td>Service Booking Url</td>
        <td>Service Video</td>
          <td colspan="2">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $servicedetailss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicedetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($servicedetails->name); ?></td>
            <td><?php echo e($servicedetails->title_one); ?></td>
            <td><?php echo e($servicedetails->title_two); ?></td>
            <td><?php echo e($servicedetails->service_image); ?></td>
            <td><?php echo e($servicedetails->content_one); ?></td>
            <td><?php echo e($servicedetails->content_two); ?></td>
            <td><?php echo e($servicedetails->content_three); ?></td> 
            <td><?php echo e($servicedetails->content_four); ?></td>
            <td><?php echo e($servicedetails->service_booking_url); ?></td>
            <td><?php echo e($servicedetails->list_one); ?></td>
            <td><?php echo e($servicedetails->list_two); ?></td>
            <td><?php echo e($servicedetails->list_three); ?></td>
            <td><?php echo e($servicedetails->list_four); ?></td>
            <td><?php echo e($servicedetails->list_five); ?></td>
            <td><?php echo e($servicedetails->list_six); ?></td>
            <td><?php echo e($servicedetails->list_seven); ?></td>
            <td><?php echo e($servicedetails->list_eight); ?></td>
            <td><?php echo e($servicedetails->service_booking_url); ?></td>
            <td><?php echo e($servicedetails->service_video); ?></td>
            <td>
                <a href="<?php echo e(route('servicedetailss.show',$servicedetails->id)); ?>" class="btn btn-primary">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($servicedetailss->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/servicedetails/servicedetailss.blade.php ENDPATH**/ ?>