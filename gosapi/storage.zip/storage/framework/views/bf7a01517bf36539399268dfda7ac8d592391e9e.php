

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-8 offset-sm-2">
        <h1 class="display-3">Update News </h1>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <br /> 
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('posts.update')); ?>" enctype="multipart/form-data">
        
            <?php echo csrf_field(); ?>
            <div class="form-group">

                <label for="name">Page Name:</label>
                <input type="text" class="form-control" name="name" value=<?php echo e($post->name); ?> />
            </div>
           
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" name="title" value=<?php echo e($post->title); ?> />
            </div>

            <div class="form-group">
        <label for="images">Post Image</label>
        <div class="custom-file">
        <input type="file" class="custom-file-input" id="images" name="post_image">
            <label class="custom-file-label" for="images">Post Image</label>
        </div>
    </div>
    <div class="form-group">
                <label for="content_one">Content One:</label>
                <textarea class="field" name="content_one" cols="50" rows="10"  ><?php echo e($post->content_one); ?></textarea>
            </div>

            <div class="form-group">
        <label for="images">Blog Image</label>
        <div class="custom-file">
        <input type="file" class="custom-file-input" id="images" name="blog_image">
            <label class="custom-file-label" for="images">Blog Image</label>
        </div>
    </div>
    <div class="form-group">
                <label for="content_two">Content Two:</label>
                <textarea class="field" name="content_two" cols="50" rows="10"  ><?php echo e($post->content_two); ?></textarea>
            </div>

            <div class="form-group">
                <label for="content_three">Content Three:</label>
                <textarea class="field" name="content_three" cols="50" rows="10"  ><?php echo e($post->content_Three); ?></textarea>
            </div>
            <div class="form-group">
                <label for="title_two">Title Two:</label>
                <input type="text" class="form-control" name="title_two" value=<?php echo e($post->title_two); ?> />
            </div>
            <div class="form-group">
                <label for="content_four">Content Four:</label>
                <textarea class="field" name="content_four" cols="50" rows="10"  value=<?php echo e($post->content_four); ?>></textarea>
            </div>

            <div class="form-group">
        <label for="images">Blog Image Two</label>
        <div class="custom-file">
        <input type="file" class="custom-file-input" id="images" name="blog_image_two">
            <label class="custom-file-label" for="images">Blog Image</label>
        </div>
    </div>
            <div class="form-group">
                <label for="title_three">Title Three:</label>
                <input type="text" class="form-control" name="title_three" value=<?php echo e($post->title_three); ?> />
            </div>
            <div class="form-group">
                <label for="content_five">Content Five:</label>
                <textarea class="field" name="content_five" cols="50" rows="10"  ><?php echo e($post->content_five); ?></textarea>
            </div>

            <div class="form-group">
                <label for="title_four">Title Four:</label>
                <input type="text" class="form-control" name="title_four" value=<?php echo e($post->title_four); ?> />
            </div>
            <div class="form-group">
                <label for="title_five">Title Five:</label>
                <input type="text" class="form-control" name="title_five" value=<?php echo e($post->title_five); ?> />
            </div>

            <div class="form-group">
                <label for="list_one">List One:</label>
                <input type="text" class="form-control" name="list_one" value=<?php echo e($post->list_one); ?> />
            </div>
            <div class="form-group">
                <label for="list_two">List Two:</label>
                <input type="text" class="form-control" name="list_two" value=<?php echo e($post->list_two); ?> />
            </div>
            <div class="form-group">
                <label for="list_three">List Three:</label>
                <input type="text" class="form-control" name="list_three" value=<?php echo e($post->list_three); ?> />
            </div>
            <div class="form-group">
                <label for="list_four">List Four:</label>
                <input type="text" class="form-control" name="list_four" value=<?php echo e($post->list_four); ?> />
            </div>
            <div class="form-group">
                <label for="list_five">List Five:</label>
                <input type="text" class="form-control" name="list_five" value=<?php echo e($post->list_five); ?> />
            </div>
            <div class="form-group">
                <label for="list_six">List Six:</label>
                <input type="text" class="form-control" name="list_six" value=<?php echo e($post->list_six); ?> />
            </div>
            <div class="form-group">
                <label for="list_seven">List Seven:</label>
                <input type="text" class="form-control" name="list_seven" value=<?php echo e($post->list_seven); ?> />
            </div>
            <div class="form-group">
                <label for="list_eight">List Eight:</label>
                <input type="text" class="form-control" name="list_eight" value=<?php echo e($post->list_eight); ?> />
            </div>
            <div class="form-group">
                <label for="list_three">List Three:</label>
                <input type="text" class="form-control" name="list_three" value=<?php echo e($post->list_three); ?> />
            </div>
            <div class="form-group">
                <label for="list_nine">List Nine:</label>
                <input type="text" class="form-control" name="list_nine" value=<?php echo e($post->list_nine); ?> />
            </div>
            <div class="form-group">
                <label for="content_six">Content Six:</label>
                <textarea class="field" name="content_six" cols="50" rows="10"  ><?php echo e($post->content_six); ?></textarea>
            </div>

            <div class="form-group">
                <label for="blog_video">Blog Video Url:</label>
                <input type="text" class="form-control" name="blog_video" value=<?php echo e($post->blog_video); ?> />
            </div>
            <div class="form-group">
        <label for="images">Blog Image Three</label>
        <div class="custom-file">
        <input type="file" class="custom-file-input" id="images" name="blog_image_three">
            <label class="custom-file-label" for="images">Blog Image Three</label>
        </div>
    </div>
    <div class="form-group">
                <label for="content_seven">Content Seven:</label>
                <textarea class="field" name="content_seven" cols="50" rows="10"><?php echo e($post->content_seven); ?></textarea>
            </div>


            <input type="hidden" name="id" value = "<?php echo e($post->id); ?>">

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/post/post.blade.php ENDPATH**/ ?>