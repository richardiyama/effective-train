

<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>Name</td>
          <td>Title One</td>
          <td>Title Two</td>
          <td>Title Three</td>
          
          
           
            
          <td colspan="2">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $nameitemtwos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nameitemtwo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($nameitemtwo->name); ?></td>
            <td><?php echo e($nameitemtwo->title_one); ?></td>
            <td><?php echo e($nameitemtwo->title_two); ?></td>
            <td><?php echo e($nameitemtwo->title_three); ?></td>
            <td><?php echo e($nameitemtwo->title_four); ?></td>
            
            <td>
                <a href="<?php echo e(route('nameitemtwos.show',$nameitemtwo->id)); ?>" class="btn btn-primary">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($nameitemtwos->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/nameitemtwo/nameitemtwos.blade.php ENDPATH**/ ?>