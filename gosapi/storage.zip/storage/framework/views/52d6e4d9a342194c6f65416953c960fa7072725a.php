

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-8 offset-sm-2">
        <h1 class="display-3">Update About Two</h1>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <br /> 
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('abouttwos.update')); ?>" enctype="multipart/form-data">
        
            <?php echo csrf_field(); ?>
            <div class="form-group">

                <label for="name">Page Name:</label>
                <input type="text" class="form-control" name="name" value=<?php echo e($abouttwo->name); ?> />
            </div>
            <div class="form-group">
        <label for="images">Image</label>
        <div class="custom-file">
        <input type="file" class="custom-file-input" id="images" name="about_image">
            <label class="custom-file-label" for="images">Image</label>
        </div>
    </div>
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" name="title" value=<?php echo e($abouttwo->title); ?> />
            </div>
            <div class="form-group">
                <label for="header_title">Header Title:</label>
                <input type="text" class="form-control" name="header_title" value=<?php echo e($abouttwo->header_title); ?> />
            </div>
            
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea class="field" name="description" cols="50" rows="10"  ><?php echo e($abouttwo->description); ?></textarea>
            </div>

            <input type="hidden" name="id" value = "<?php echo e($abouttwo->id); ?>">

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/abouttwo/abouttwo.blade.php ENDPATH**/ ?>