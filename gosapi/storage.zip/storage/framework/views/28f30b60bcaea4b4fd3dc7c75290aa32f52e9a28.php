

<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>Name</td>
          <td>Phone Title</td>
           <td> Phone Number One</td>
            <td>Phone Number Two</td>
            <td>Email Title</td>
            <td>Email One</td>
            <td>Email Two</td>

          <td colspan="2">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $contacttopareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacttoparea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($contacttoparea->name); ?></td>
            <td><?php echo e($contacttoparea->phone_title); ?></td>
            <td><?php echo e($contacttoparea->phone_number_one); ?></td>
            <td><?php echo e($contacttoparea->phone_number_two); ?></td>
            <td><?php echo e($contacttoparea->email_title); ?></td>
            <td><?php echo e($contacttoparea->email_one); ?></td>
            <td><?php echo e($contacttoparea->email_two); ?></td>
            
        
            <td>
                <a href="<?php echo e(route('contacttopareas.show',$contacttoparea->id)); ?>" class="btn btn-primary">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($contacttopareas->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\gosApi\gosapi\resources\views/contacttoparea/contacttopareas.blade.php ENDPATH**/ ?>